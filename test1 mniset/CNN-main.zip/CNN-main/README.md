# CNN you should run load_data first before you run train
