# Resnet50---pytorch-implementation
###### making ResNet-50 for MNIST  in pytorch

The model reached 85.6 and 85.1 train and test accuracy respectively with just 5 epochs on MNIST handwritten digits data.
20 epochs are expected to give whopping accuracy.

